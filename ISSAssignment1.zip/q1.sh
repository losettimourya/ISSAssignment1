#!/bin/bash
echo "Output after removing empty lines:"
sed '/^[[:space:]]*$/d' quotes.txt
echo "Output after removing duplicates:"
awk '!a[$0]++' quotes.txt 

