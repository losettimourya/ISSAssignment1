#!/bin/bash
echo "Enter file name"
read
echo "The words in each line are:"
awk '{print "Line No:",NR,"Count of Words:",NF}' $REPLY

