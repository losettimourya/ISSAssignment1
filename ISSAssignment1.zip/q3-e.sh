#!/bin/bash
echo "Enter file name"
read
echo "The frequency of repeated words is:"
cat $REPLY | sed '/^[[:space:]]*$/d' | tr ' ' '\n' | sort | uniq -dc | awk '{print "Word:"$2" - Count of repetition:"$1}'
