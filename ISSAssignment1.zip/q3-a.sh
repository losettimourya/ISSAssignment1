#!/bin/bash
echo "Enter file name"
read
echo "The size of file in bytes is:"
cat $REPLY | wc -c
