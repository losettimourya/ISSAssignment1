#!/bin/bash
echo "Enter file name"
read
echo "The total number of words in the file is:"
cat $REPLY | wc -w
