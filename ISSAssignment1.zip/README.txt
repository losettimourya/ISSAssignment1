For q4 , I assumed that the input is given including commas.

Github Repository link:  https://github.com/losettimourya/ISSAssignment1.git/

