For q1 , i did the required operations in the file itself.

For q4 , I assumed that the input is given including commas.

Github Repository link:  https://github.com/losettimourya/ISSAssignment1.git/

