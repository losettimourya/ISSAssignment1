#!/bin/bash
echo "Enter file name"
read
echo "The total number of lines in the file is:"
cat $REPLY | wc -l
