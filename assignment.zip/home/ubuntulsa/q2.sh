#!/bin/bash
awk '{print $NF" said ""\""}' quote.txt | echo ${$0    
