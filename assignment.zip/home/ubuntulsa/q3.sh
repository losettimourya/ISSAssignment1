#!/bin/bash
echo "Enter file name"
read
echo "The size of the file in bytes is:"
cat $REPLY | wc -c
echo "The total number of lines in the file are:"
cat $REPLY | wc -l
echo "The total number of words in the file are:"
cat $REPLY | wc -w
echo "The words in each line are:"
awk '{print "Line No:",NR,"Count of Words:",NF}' $REPLY
echo "The frequency of repeated words is:"
cat $REPLY | tr ' ' '\n' | sort | uniq -dc | awk '{print "Word:"$2"-Count of repitition:"$1}'


