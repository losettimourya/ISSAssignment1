#!/bin/bash
sed -i '/^[[:space:]]*$/d' quotes.txt
awk '!a[$0]++' quotes.txt > quotes.tmp && mv quotes.tmp quotes.txt

