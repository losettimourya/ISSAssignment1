#!/bin/bash
declare -a arr
IFS=','
echo "Enter array elements:"
read -a arr
for((i=0;i<${#arr[*]};i++))
do
for((j=$i;j<${#arr[*]};j++))
do
if [ ${arr[$i]} -gt ${arr[$j]} ]
then
temp=${arr[$i]}
arr[$i]=${arr[$j]}
arr[$j]=$temp
fi
done
done
echo "The sorted array is:"
echo ${arr[*]}
