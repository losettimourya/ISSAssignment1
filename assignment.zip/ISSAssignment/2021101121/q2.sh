#!/bin/bash
file=quotes.txt
IFS='~'
while read line
do
if [ ! -z "$line" ]
then
read -a stored <<< "$line"
echo -n ${stored[1]} "once said "
echo -n '"'
echo -n ${stored[0]}
echo '"'
fi
done <$file>speech.txt
